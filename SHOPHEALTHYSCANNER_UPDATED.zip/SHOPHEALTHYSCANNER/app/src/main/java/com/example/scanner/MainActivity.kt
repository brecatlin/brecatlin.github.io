package com.example.scanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.budiyev.android.codescanner.AutoFocusMode
import com.budiyev.android.codescanner.CodeScanner
import com.budiyev.android.codescanner.CodeScannerView
import com.budiyev.android.codescanner.DecodeCallback
import com.budiyev.android.codescanner.ErrorCallback
import com.budiyev.android.codescanner.ScanMode


class MainActivity : AppCompatActivity() {

    private lateinit var codeScanner: CodeScanner
    private val ingredientDatabase: HashMap<String, String> = HashMap()  // Using HashMap for efficiency

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val scannerView = findViewById<CodeScannerView>(R.id.scanner_view)
        val seekBar = findViewById<SeekBar>(R.id.seekBar)

        codeScanner = CodeScanner(this, scannerView)

        // Initialize HashMap with ingredient data
        initializeIngredientDatabase()

        // CodeScanner configuration
        codeScanner.apply {
            camera = CodeScanner.CAMERA_BACK
            formats = CodeScanner.ALL_FORMATS
            autoFocusMode = AutoFocusMode.SAFE
            scanMode = ScanMode.SINGLE
            isAutoFocusEnabled = true
            isFlashEnabled = false

            // Callbacks
            decodeCallback = DecodeCallback { result ->
                runOnUiThread {
                    val barcode = result.text
                    val matchedIngredient = searchIngredient(barcode)
                    if (matchedIngredient != null) {
                        Log.d("Ingredient Found", matchedIngredient)
                        Toast.makeText(
                            this@MainActivity,
                            "Ingredient Found: $matchedIngredient",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Log.d("No Match", "Ingredient not found in the database.")
                        Toast.makeText(
                            this@MainActivity,
                            "No ingredient match found for the barcode.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }

            errorCallback = ErrorCallback { error ->
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "Camera initialization error: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        // SeekBar listener to adjust zoom level
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                codeScanner.zoom = progress
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // No action needed here
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // No action needed here
            }
        })

        // Request camera permission
        checkPermission(Manifest.permission.CAMERA, 200)

        // Start scanner on click
        scannerView.setOnClickListener {
            codeScanner.startPreview()
        }
    }

    // Initialize the HashMap with ingredients and barcodes
    private fun initializeIngredientDatabase() {
        ingredientDatabase["1234567890"] = "Sugar, Dairy, Gluten"
        ingredientDatabase["0987654321"] = "Salt, Vegan, Nut-free"
        // Add more ingredients as needed
    }

    // Function to search for an ingredient based on barcode using HashMap (efficient O(1) lookup)
    private fun searchIngredient(barcode: String): String? {
        return ingredientDatabase[barcode]
    }

    // Request for camera permission
    private fun checkPermission(permission: String, reqCode: Int) {
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(permission), reqCode)
        }
    }

    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }
}

