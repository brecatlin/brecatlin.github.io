package com.example.shophealthy;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private SQLiteDatabase userDatabase;
    private SQLiteDatabase ingredientDatabase;
    private GridView dataGridView;
    private SimpleCursorAdapter adapter;
    private EditText usernameEditText, passwordEditText, dietaryPreferenceEditText, barcodeEditText;
    private Button loginButton, createAccountButton, scanBarcodeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements for user login and dietary preference management
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        dietaryPreferenceEditText = findViewById(R.id.dietaryPreferenceEditText);
        barcodeEditText = findViewById(R.id.barcodeEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        scanBarcodeButton = findViewById(R.id.scanBarcodeButton);

        // Open or create the user database
        userDatabase = openOrCreateDatabase("UserDB", MODE_PRIVATE, null);
        // Create a user table if not exists
        userDatabase.execSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, dietaryPreference TEXT)");

        // Add text change listener to enable/disable login button based on input fields
        usernameEditText.addTextChangedListener(textWatcher);
        passwordEditText.addTextChangedListener(textWatcher);

        // Set up click listeners for login and create account buttons
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }
        });

        // Initialize UI elements for barcode scanning and ingredient management
        dataGridView = findViewById(R.id.dataGridView);

        // Open or create the ingredient database
        ingredientDatabase = openOrCreateDatabase("IngredientDB", MODE_PRIVATE, null);
        // Create an ingredient table if not exists
        ingredientDatabase.execSQL("CREATE TABLE IF NOT EXISTS ingredients (id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT, ingredientData TEXT)");

        // Set up click listener for the Scan Barcode button
        scanBarcodeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanBarcode();
            }
        });

        // Populate GridView with ingredients for demonstration
        refreshGridView();
    }

    // TextWatcher to enable/disable login button based on input fields
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}

        @Override
        public void afterTextChanged(Editable s) {
            loginButton.setEnabled(!usernameEditText.getText().toString().isEmpty() &&
                    !passwordEditText.getText().toString().isEmpty());
        }
    };

    // Method to handle user login
    private void login() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        Cursor cursor = userDatabase.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password});
        if (cursor.getCount() > 0) {
            // User authenticated
            cursor.moveToFirst();
            String dietaryPreference = cursor.getString(cursor.getColumnIndex("dietaryPreference"));
            Toast.makeText(this, "Login successful! Dietary Preference: " + dietaryPreference, Toast.LENGTH_SHORT).show();
        } else {
            // Authentication failed
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    // Method to handle account creation
    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String dietaryPreference = dietaryPreferenceEditText.getText().toString().trim();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        values.put("dietaryPreference", dietaryPreference);

        long rowId = userDatabase.insert("users", null, values);
        if (rowId != -1) {
            // Account created successfully
            Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show();
        } else {
            // Account creation failed
            Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to scan a barcode and match ingredients
    private void scanBarcode() {
        String barcode = barcodeEditText.getText().toString().trim();

        Cursor cursor = ingredientDatabase.rawQuery("SELECT * FROM ingredients WHERE barcode=?", new String[]{barcode});
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String ingredientData = cursor.getString(cursor.getColumnIndex("ingredientData"));
            Toast.makeText(this, "Ingredient Found: " + ingredientData, Toast.LENGTH_SHORT).show();
        } else {
            // No matching ingredient found
            Toast.makeText(this, "No matching ingredients found for this barcode.", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    // Method to refresh GridView with ingredient data
    private void refreshGridView() {
        Cursor cursor = ingredientDatabase.rawQuery("SELECT * FROM ingredients", null);
        if (cursor != null) {
            adapter = new SimpleCursorAdapter(
                    this,
            android.R.layout.simple_list_item_1,
            cursor,
            new String[]{"ingredientData"},
            new int[]{android.R.id.text1},
            0);

            dataGridView.setAdapter(adapter);
        }
    }

    @Override
    protected void onDestroy() {
        // Close the databases when the activity is destroyed
        if (userDatabase != null && userDatabase.isOpen()) {
            userDatabase.close();
        }
        if (ingredientDatabase != null && ingredientDatabase.isOpen()) {
            ingredientDatabase.close();
        }
        super.onDestroy();
    }
}