package com.example.scanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.budiyev.android.codescanner.AutoFocusMode
import com.budiyev.android.codescanner.CodeScanner
import com.budiyev.android.codescanner.CodeScannerView
import com.budiyev.android.codescanner.DecodeCallback
import com.budiyev.android.codescanner.ErrorCallback
import com.budiyev.android.codescanner.ScanMode

class MainActivity : AppCompatActivity() {

    private lateinit var codeScanner: CodeScanner

    // List to store ingredients associated with barcodes
    private val ingredientList = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val scannerView = findViewById<CodeScannerView>(R.id.scanner_view)

        // Initialize CodeScanner
        codeScanner = CodeScanner(this, scannerView)

        // Initialize the list with ingredient data
        initializeIngredientList()

        // CodeScanner configuration
        codeScanner.apply {
            camera = CodeScanner.CAMERA_BACK
            formats = CodeScanner.ALL_FORMATS
            autoFocusMode = AutoFocusMode.SAFE
            scanMode = ScanMode.SINGLE
            isAutoFocusEnabled = true
            isFlashEnabled = false

            // Callbacks
            decodeCallback = DecodeCallback { result ->
                runOnUiThread {
                    val barcode = result.text
                    val matchedIngredient = searchIngredient(barcode)
                    if (matchedIngredient != null) {
                        Toast.makeText(
                            this@MainActivity,
                            "Ingredient Found: $matchedIngredient",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            this@MainActivity,
                            "No ingredient match found for the barcode.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }

            errorCallback = ErrorCallback { error ->
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "Camera initialization error: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        // Request camera permission
        checkPermission(Manifest.permission.CAMERA, 200)

        // Start scanner on click
        scannerView.setOnClickListener {
            codeScanner.startPreview()
        }
    }

    // Initialize the list with ingredients and barcodes
    private fun initializeIngredientList() {
        ingredientList.add(Pair("1234567890", "Sugar, Dairy, Gluten"))
        ingredientList.add(Pair("0987654321", "Salt, Vegan, Nut-free"))
        // Add more ingredients as needed
    }

    // Function to search for an ingredient based on barcode using a list (O(n) lookup)
    private fun searchIngredient(barcode: String): String? {
        for (pair in ingredientList) {
            if (pair.first == barcode) {
                return pair.second
            }
        }
        return null
    }

    // Request for camera permission
    private fun checkPermission(permission: String, reqCode: Int) {
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(permission), reqCode)
        }
    }

    override fun onResume() {
        super.onResume()
        codeScanner.startPreview()
    }

    override fun onPause() {
        codeScanner.releaseResources()
        super.onPause()
    }
}
